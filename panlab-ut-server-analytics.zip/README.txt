Pan Lab – U of T server Cloudflare Web Analytics package
========================================================

Contents
--------
Six HTML pages for the existing /panlab/ directory:
  index.html
  Research.html
  People.html
  Lab_News.html
  Publications.html
  Join.html

Installation
------------
1. Back up the existing six HTML files on the U of T server.
2. Extract this ZIP on your computer.
3. Upload the six HTML files to the existing individual.utoronto.ca/panlab/ directory,
   overwriting the matching files there.
4. Do not upload these files to the server's top-level directory.
5. Keep the existing PanLab.css file and images/ folder in place; this package does
   not include or replace shared CSS or image assets.

Analytics separation
--------------------
Each page contains exactly one Cloudflare Web Analytics beacon using the U of T
server token supplied for individual.utoronto.ca. The panlab.ca token has been
replaced, not retained, so the two site entry points are tracked separately.

Source
------
Prepared from xuepanlab/panlab.ca main at commit:
b312b6be662cfa670679bea8b6ff28a6f15fa1b2

No live website or server files were changed when this package was prepared.
